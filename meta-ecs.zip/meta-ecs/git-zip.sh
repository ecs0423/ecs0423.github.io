#!/bin/bash
FILE_NAME=$(pwd | rev | cut -d "\\" -f 1 | rev)_$(git log --date=short --pretty=format:"%ad-%h" -1)
FORMAT=zip
git archive --format zip -o ${FILE_NAME}.zip HEAD
echo Output ${FILE_NAME}.${FORMAT} !!
