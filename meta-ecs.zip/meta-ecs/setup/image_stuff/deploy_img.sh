#pushd tmp/deploy/images/intel-quark
IMG_NAME='image-ecs'

rm -rf img
mkdir img
cp -r boot_poky img/boot
cp bzImage img/
cp core-image-minimal-initramfs-intel-quark.cpio.gz img/core-image-minimal-initramfs-quark.cpio.gz
cp grub.efi img/
cp ${IMG_NAME}-intel-quark.ext3 img/image-full-quark.ext3
ls img/
