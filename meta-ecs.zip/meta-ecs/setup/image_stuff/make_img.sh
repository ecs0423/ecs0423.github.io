TOOLPATH='../setup/asset-signing-tool/'

#make image
pushd tmp/deploy/images/intel-quark
chmod +x deploy_img.sh
./deploy_img.sh
popd

#copy image
rm -rf img
mv tmp/deploy/images/intel-quark/img/ .  || { echo "command failed"; exit 1; }
#cp  ../../sysimage_v1.2.1.1/config/key.pem .
# find img/ -name "*.csbh"|xargs rm
#find img/

#sign key
sudo ./${TOOLPATH}sign -c -s 0 -k ./${TOOLPATH}key.pem -i ./img/bzImage -x 6 -b 0x400  || { echo "command failed"; exit 1; }
sudo ./${TOOLPATH}sign -c -s 0 -k ./${TOOLPATH}key.pem -i ./img/core-image-minimal-initramfs-quark.cpio.gz -x 7 -b 0x400  || { echo "command failed"; exit 1; }
sudo ./${TOOLPATH}sign -c -s 0 -k ./${TOOLPATH}key.pem -i ./img/boot/grub/grub.conf -x 5 -b 0x400  || { echo "command failed"; exit 1; }

echo "Output image file! Success"
find img/
